$(document).ready(function(){

  getCurrentTime();

$("#nameForm").submit(function() {
  var a = $("input#Name").val();
  localStorage.setItem("Username",a);
pageReady();
});
});
function getCurrentTime(){
     var d = new Date();
     var hr = d.getHours();
     var min = d.getMinutes();
     var sec = d.getSeconds();
     cur_Date = hr + ":" + min + ":" +sec;
     setTimeout("getCurrentTime()",1000);
     // console.log(cur_Date);
     $("p#current_Time").text(cur_Date)  ;
}
function pageReady()
{
  var UserName =   localStorage.getItem(Username);
    $("span#greetName").text(UserName);
}
