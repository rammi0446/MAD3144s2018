
//  $("#formName").submit(function() {
//    alert("gello");
// var name= $("input#enterName").val();
// console.log(name);
// $("span#greetName").text("hii");
//
//
// })

$(document).keypress(function(e) {
    if(e.which == 13) {
        alert('You pressed enter!');
        var name= $("input#enterName").val();
         console.log(name);
         $("span#greetName").val(name);
    }
});

function getCurrentTime(){
     var d = new Date();
     var hr = d.getHours();
     var min = d.getMinutes();
     var sec = d.getSeconds();
     cur_Date = hr + ":" + min + ":" +sec;
     setTimeout("getCurrentTime()",1000);
     // console.log(cur_Date);
     $("p#current_Time").text(cur_Date)  ;
	if(hr>12 && hr<=16)
	{
	$("span#Good").text("Good Evening");
	}
	if(hr>16)
	{
	$("span#Good").text("Good Night");
	}
	else{
	$("span#Good").text(" Good Morning");
	}
}
$(document).ready(function(){

 getCurrentTime();


});
