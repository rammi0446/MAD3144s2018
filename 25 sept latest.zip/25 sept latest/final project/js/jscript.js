



function getCurrentTime(){
     var d = new Date();
     var hr = d.getHours();
     var min = d.getMinutes();
     var sec = d.getSeconds();
     cur_Date = hr + ":" + min + ":" +sec;
     setTimeout("getCurrentTime()",1000);
     // console.log(cur_Date);
     $("p#current_Time").text(cur_Date)  ;
	if(hr>=12 && hr<=20)
	{
	$("span#Good").text("Good Evening");
	}
	if(hr>20)
	{
	$("span#Good").text("Good Night");
	}
	if(hr<12){
	$("span#Good").text(" Good Morning");
	}
}
$(document).ready(function(){

 getCurrentTime();
var a;
$("#enterName").on("keypress",function(e)

 {
   if(e.which == 13) {
 	alert('You pressed enter!');
	  var a = $("#enterName").val();
        //$("span#greetName").text(a);
	localstorage.setItem("Name",a);
	$("span#greetName").val() = localstorage.getItem("Name");

}
});
 

$("#enterFocus").on("keypress",function(e) {
    if(e.which == 13) {
 	alert('You pressed enter!');
	var a = $("#enterFocus").val();
        $("span#greetFocus").text(a);
    }
});



});
