

pageReady();
var focusTask = false;
var maxField = 10; 
var todoCounter = 0;

var todos = new Array(localStorage.getItem("todo0"),localStorage.getItem("todo1"),localStorage.getItem("todo2"),localStorage.getItem("todo3"),localStorage.getItem("todo4"),localStorage.getItem("todo5"),localStorage.getItem("todo6"),localStorage.getItem("todo7"),localStorage.getItem("todo8"),localStorage.getItem("todo9"));

/*------------------Checking Username, Focus and Showing forms according to the conditions-------------------*/
function pageReady() {
    
var user = localStorage.getItem("userName");
var focus = localStorage.getItem("todayFocus");


console.log(user);

if (user != null) {

      $("#user").text(user);
      $("#nameForm").hide();
      $("#HelloText").hide();
       $("#todo_box").hide();
        $("#todo").show();
    
      if (focus == null) {
            $("#focusForm").show();
            $("#GreetText").show();  
            $("#focus_list").hide();
            $("#todo_box").hide();
            $("#todo").show();
      }
      else {
            $("#focusForm").hide();  
            $("#focus_list").show();
            $("#GreetText").hide();  
            $("#focus_chkbox").text(focus);  
             $("#todo_box").hide();
            $("#todo").show();
      }
      
  } else {
      $("#focus_list").hide();
      $("#focusForm").hide();
      $("#GreetText").hide();
      $("#nameForm").show();
      $("#HelloText").show();
      $("#todo_box").hide();
        $("#todo").hide();

  }

}

/*------------------Getting Main Task of the day from user-------------------*/

  $("#focusForm").submit(function () {

      var todayFocus = $("input#today_focus").val();
      if(todayFocus == "") {
          alert("Textbox can't be empty");
      }
      else {
      console.log(todayFocus);

      $("input#today_focus").val("");
      
      localStorage.setItem("todayFocus", todayFocus);
      
      pageReady();
      location.reload();
      }
  })


/*------------------Getting Name from user-------------------*/
  $("#nameForm").submit(function () {

      var user = $("input#userName").val();
      if(user == "") {
          alert("Name can't be empty");
      }
      else {
      localStorage.setItem("userName", user);
      pageReady();
    
      }
      
  })


/*------------------Hiding and SHowing Main task Button-------------------*/

 $("#focus_list").hover(function(){
       $("#check_focus").fadeIn(300);
        $("#delete_focus").fadeIn(300);
    },
    function(){
         $("#check_focus").fadeOut(300);
        $("#delete_focus").fadeOut(300);
    }); 
 

/*------------------------Done And Undone the Task------------------------------*/

$("#check_focus").click(chk_focus);
$("#focus_chkbox").click(chk_focus);
    
    
function chk_focus()
{
    if(focusTask==false) {
    $("#focus_chkbox").css("text-decoration","line-through");
        $("#taskStatus").text(": Completed");
        focusTask=true;
    }
    else {
    $("#focus_chkbox").css("text-decoration","none");
        $("#taskStatus").text(": Pending");
        focusTask=false;
    }    
}


/*------------------------Delete Task------------------------------*/
$("#delete_focus").click(function(){
    focusTask = false;
    $("#focus_chkbox").css("text-decoration","none");
    localStorage.removeItem("todayFocus");
    pageReady();
})


/*--------------------------Show Hide Todo List---------------------------------------*/

$("#todo_btn").click(function(){
      $("#todo_box").toggle();               
    
})

/*------------------------------Add Remove todo List------------------------------*/

$('#todo_box ul').delegate("li", "click",".remove", function() {
   var id=$(this).attr('id');
    $(this).parents('a').remove();
   alert("ID:"+id);  
});



$(document).ready(function(){
	
	var addButton = $('.add_button'); //Add button selector
	var wrapper = $('.field_wrapper'); //Input field wrapper
	var fieldHTML = '<div><input type="checkbox" name="field_name[]" value=""/>'; 
    var fieldHTML2 = '<a href="#" href="javascript:void(0);" title="Remove" class="del_todo" > <i class="fas fa-times todo_icn"></i> </a</div>'//New input field html 
    var i;
	for (i = 0; i<todos.length; i++)
    {
        if(todos[i] != null) {
        $(wrapper).append(fieldHTML + todos[i] + fieldHTML2); // Add field html    
        }   
        else 
            {
                break;
            }
        todoCounter = i;
    }
	
    $("#todoForm").submit(function(e){//Once add button is clicked
		
        var todoTask = $("input#todoTask").val();

        if(todoTask == "") {
          alert("Textbox can't be empty");
      }
      else {
        
        $("input#todoTask").val("");
        if(todoCounter < maxField){ //Check maximum number of input fields
			console.log(todoCounter);
            
            var temp = "todo" + todoCounter;
            localStorage.setItem(temp, todoTask);
            
            todoCounter++; //Increment field counter
            
			$(wrapper).append(fieldHTML + todoTask + fieldHTML2); // Add field html
            e.preventDefault();
		}
      }
	});
    
    $(document).on('click', '.del_todo', function(e) {
    $(this).parent().remove();
        
        var temp = "todo" + todoCounter;
            localStorage.removeItem(temp);
            
        e.preventDefault();
        todoCounter--;
        console.log(todoCounter);
    });
});