
/*-------------------------------------Getting and Showing Date--------------------------------*/

function getDate() {
        
    var mydate = new Date();
    var year = mydate.getYear();
    var month = mydate.getMonth();
    var day = mydate.getDay();
    var dayM = mydate.getDate();
    
    var dayName = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
    
    var monthName = new Array("Jan","Feb","Mar","Apr","May","June","July","Aug","Sep","Oct","Nov","Dec");
    
    if(year<1000){
        year = year + 1900;
    }
    
    var current_date = document.getElementById("current_date");
    current_date.innerHTML = monthName[month] + " " + dayM + ", " + year + " | " + dayName[day] ;
     
    console.log(current_date);
    
}

/*-------------------------------------Getting and Showing Time and Greetings--------------------------------*/

function getTime() {

    var mytime = new Date();
    var hours = mytime.getHours();
    var mins = mytime.getMinutes();
    var secs = mytime.getSeconds();
    
    var greeting = document.getElementById("greet"); 
    
    
    if (hours<12)
        {
            greeting.textContent = "Morning";
        }
    else if (hours>=12 && hours<16)
        {
            greeting.textContent = "Afternoon";
        }
    else if (hours>=16 && hours<20)
        {
            greeting.textContent = "Evening";
        }
    else 
        {
            greeting.textContent = "Night";
        }
    
    
    if(hours<10){
        hours = "0"+hours;
    }
    if(mins<10){
        mins = "0"+mins;
    }
    if(secs<10){
        secs = "0"+secs;
    }
    

    
    
    var currentTime = document.getElementById("time");
    
    currentTime.textContent = hours + ":" + mins + ":" + secs;
    setTimeout("getTime()",1000);
    
    
}


/*-------------------------------------Getting Current Location of User from Browser for Weather data--------------------------------*/
var weatherID = document.getElementById("weatherdata");

function getLocation() {

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(getWeather);
    } else { 
        weatherID.innerHTML = "Geolocation is not supported by this browser.";
    }


/*-------------------------------------Getting weather from api according to the geolocation--------------------------------*/
function getWeather(position) {
    
    var url_1 = 'http://api.openweathermap.org/data/2.5/weather?lat=';
    var url_2 = "&lon=";
    var units = "&units=metric"
    var apiKey = "&appid=6dad1782d55cedf3d024e09215ce4974"
    
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;

    var cmplt = url_1 + latitude + url_2 + longitude + units + apiKey;
    console.log(cmplt);
        
    fetch(cmplt)
        .then(res => res.json())
        .then((out) => {
            var iconURL = "http://openweathermap.org/img/w/";
            var iconID = out.weather[0]["icon"];
            var fullURL = iconURL+iconID+".png";
        
             document.getElementById("weatherImg").src = fullURL; 
            
            console.log(iconID);
            
         weatherID.innerHTML = " Temp: " +out.main.temp+"&#8451;" + " | " + "City: " + out.name;
        })
        .catch(err => { throw err });
    


}
setTimeout("getWeather()",120000);      //---Get Data after every Two Minutes
}
/*-------------------------------------Changing background images on daily basis--------------------------------*/

function setBG() {
    
    var url = "https://source.unsplash.com/daily?dark?nature";
    var bgDate = new Date();
    localStorage.setItem("bgDate",bgDate);
    localStorage.setItem("Background","url(" + url + ")");
    document.getElementById('mycontainer').style.backgroundImage = "url(" + url + ")";
}





/*-------------------------------------Function Calls--------------------------------*/

setBG();
getLocation();
getDate();
getTime();
