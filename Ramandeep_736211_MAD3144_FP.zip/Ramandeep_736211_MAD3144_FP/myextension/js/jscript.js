



function fun2()
{
	getCurrentTime();
	$("#divList").hide();
	$("#Good").hide();
	//    ---------------------name-------------
	document.getElementById('nameshow').innerHTML = localStorage.getItem('name');
	$("#namehide").hide();
	$("#inputName").hide();
	$("#Good").show();
					if(localStorage.getItem("focus") === null)
					{
							console.log("focus is null");
							$("#inputFocus").show();
							enterFocus();
							console.log(" name contains");
					}
					else{
						$("#inputFocus").hide();

				 var li = document.createElement("li");
					var inputFocus = localStorage.getItem('focus');
					var t = document.createTextNode(inputFocus);
					li.appendChild(t);
					if (inputFocus === '') {
					alert("You must write something!");
					} else {
					document.getElementById("myULFocus").appendChild(li);
	}
	document.getElementById("inputFocus").value = "";
	var span = document.createElement("SPAN");
	var txt = document.createTextNode("\u00D7");
	span.className = "close";
	span.appendChild(txt);
	li.appendChild(span);

	for (i = 0; i < close.length; i++) {
		close[i].onclick = function() {
			var div = this.parentElement;
			div.style.display = "none";
			localStorage.removeItem('focus');
		}
	
	}

					}
	//---------focus-------------
	//$("#inputFocus").hide();
	
}
/////////////////// document start---------------------------------------------------

$(document).ready(function() {


//reload--------------------------------------------------if focus null----------------------------------------




if(localStorage.getItem("name") === null)
		{
			getCurrentTime();
			$("#divList").hide();
			$("#Good").hide();

				enterPressed();
				enterFocus();
			}
else{
				

								fun2();
}
///     ----------------------------name null---------------------
	
	//------ready function start--------


	//-------function 1 and function2-------------




});



//   submit start
var toSubmit = function() {
var text = $("#inputName").val();
console.log(text);
//$("#nameshow").text(text);
localStorage.setItem("name",text);
var name = localStorage.getItem("name");
//$("#nameshow").text(localStorage.getItem("name"));

function fun1()
{
var text = $("#inputName").val();
console.log(text);
localStorage.setItem("name",text);
var name = localStorage.getItem("name");
$("#nameshow").text(localStorage.getItem("name"));
$("#namehide").hide();
$("#inputName").text("");
$("#inputName").hide();
	$("#Good").show();
}
fun1();
};
// submit ends

// enterPressed start
var enterPressed = function() {
$('#inputName').keyup(function(event) {
if(event.which == 13) {
	toSubmit();
}
	});
};
// endPressed end




//------------focus function start-----------------



var toFocus = function() {
$("#inputFocus").hide();
var li = document.createElement("li");
var inputFocus = document.getElementById("inputFocus").value;
localStorage.setItem("focus",inputFocus);
var t = document.createTextNode(inputFocus);
li.appendChild(t);
if (inputFocus === '') {
alert("You must write something!");
	}
	else {
		document.getElementById("myULFocus").appendChild(li);
	}
	document.getElementById("inputFocus").value = "";

	var span = document.createElement("SPAN");
	var txt = document.createTextNode("\u00D7");
	span.className = "close";
	span.appendChild(txt);
	li.appendChild(span);

	for (i = 0; i < close.length; i++) {
		close[i].onclick = function() {

			var div = this.parentElement;
			div.style.display = "none";
			localStorage.removeItem('focus');
		}
	
	}


	}


	var enterFocus = function() {
		$('#inputFocus').keyup(function(event) {
			if(event.which == 13) {
				toFocus();
			}
		});
	};
	/// focus function ends-----------------



//--------------------todolist div-------------------

function myFunction() {
    var x = document.getElementById("divList");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}
//-----------------links div------------
function linksshow() {
    var x = document.getElementById("links");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}


//-----------------------------get current time------------------------
function getCurrentTime(){
     var d = new Date();
     var hr = d.getHours();
     var min = d.getMinutes();
     var sec = d.getSeconds();
     cur_Date = hr + ":" + min + ":" +sec;
     setTimeout("getCurrentTime()",1000);
     // console.log(cur_Date);
     $("p#current_Time").text(cur_Date)  ;
	if(hr>=12 && hr<=20)
	{
	$("span#Good").text("Good Evening");
	}
	if(hr>20)
	{
	$("span#Good").text("Good Night");
	}
	if(hr<12){
	$("span#Good").text(" Good Morning");
	}
}

//--------------------create focus----------------------









//-----------------------to do list-----------------------

// Create a "close" button and append it to each list item
var myNodelist = document.getElementsByTagName("LI");

var i;
for (i = 0; i < myNodelist.length; i++) {
  var span = document.createElement("SPAN");
  var txt = document.createTextNode("\u00D7");
  span.className = "close";
  span.appendChild(txt);
  myNodelist[i].appendChild(span);
}

// Click on a close button to hide the current list item
var close = document.getElementsByClassName("close");
var i;
for (i = 0; i < close.length; i++) {
  close[i].onclick = function() {
    var div = this.parentElement;
    div.style.display = "none";
  }
}

// Add a "checked" symbol when clicking on a list item
var list = document.querySelector('ul');
list.addEventListener("click", function(ev) {
  if (ev.target.tagName === 'LI') {
    ev.target.classList.toggle('checked');
    console.log("hello list item");
  }
}, false);

// Create a new list item when clicking on the "Add" button
function newElement() {

  var li = document.createElement("li");
  var inputValue = document.getElementById("myInput").value;

  
  var t = document.createTextNode(inputValue);
  li.appendChild(t);
  if (inputValue === '') {
    alert("You must write something!");
  } else {
    document.getElementById("myUL").appendChild(li);
  }
  document.getElementById("myInput").value = "";

  var span = document.createElement("SPAN");
  var txt = document.createTextNode("\u00D7");
  span.className = "close";
  span.appendChild(txt);
  li.appendChild(span);

  for (i = 0; i < close.length; i++) {
    close[i].onclick = function() {
      var div = this.parentElement;
      div.style.display = "none";
    }
  }
}




    var imgCount = 2;
        var dir = 'images/';
        var randomCount = Math.round(Math.random() * (imgCount - 1)) + 1;
        var images = new Array
               
                images[1] = "bg.jpg",
                images[2] = "bg1.jpg",
        document.getElementById("back").style.backgroundImage = "url(" + dir + images[randomCount] + ")"; 
  