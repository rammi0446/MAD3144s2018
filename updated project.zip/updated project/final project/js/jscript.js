function getCurrentTime(){
      var d = new Date();
      var hr = d.getHours();
      var min = d.getMinutes();
      var sec = d.getSeconds();

var cur_Date = document.getElementById("current_Date");

cur_Date = hr + ":" + min + ":" +sec;
setTimeout("getCurrentTime()",1000);
console.log(cur_Date);

}

getCurrentTime();
